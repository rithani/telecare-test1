﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1.BLL
{
    public class LuxuryCar : BasicCar
    {
        public bool NavigationSystem { get; set; }

        public bool BlueToothSupport { get; set; }
    }
}
