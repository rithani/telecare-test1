﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1.BLL
{
    public interface ICar
    {
        decimal Price { get; set; }

        string Color { get; set; }

        float SafetyRating { get; set; }
    }
}
