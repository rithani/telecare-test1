﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1.BLL
{
    public class CarFactory
    {
        public static Car GetCarByType(string carType)
        {
            Car c = null;
            switch (carType)
            {
                case "Basic":
                    c = new BasicCar();
                    break;
                case "Luxury":
                    c = new LuxuryCar();
                    break;
            }

            return c;
        }
    }
}
