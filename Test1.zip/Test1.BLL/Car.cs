﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1.BLL
{
    public abstract class Car
    {
        public decimal Price { get; set; }

        public string color { get; set; }

        public float SafetyRating { get; set; }
        
    }
}
