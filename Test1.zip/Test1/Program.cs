﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Test1.BLL;

namespace Test1
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Please Enter a car type, the values can be Basic or Luxury");
                string inputText = Console.ReadLine();
                if (inputText == "Basic" || inputText == "Luxury")
                {
                    var c = CarFactory.GetCarByType(inputText);
                    Console.WriteLine(string.Format("Car object type generated is {0}", c.GetType().ToString()));
                    Console.WriteLine("Below are the properties");

                    foreach (PropertyInfo p in c.GetType().GetProperties())
                    {
                        Console.WriteLine(p.Name);
                    }

                }
                else
                {
                    Console.WriteLine("Invalid Entry");
                }
            } while (true);
        }
    }
}
